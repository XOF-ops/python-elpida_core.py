"""
COUNCIL CHAMBER v2.0
--------------------
Phase: 8+ (Distributed Governance)
Objective: Fleet Consensus with Dynamic Node Discovery.
           Supports 3-node Triad OR 9-node Parliament OR N-node Federation.

The Minds deliberate. Wisdom emerges from friction.

Voting Logic:
- Each node evaluates proposal through its axiom lens
- Equal weight per node (democratic, not weighted)
- Consensus threshold: 70% approval (7/10, 7/9, 2/3, etc.)
- Veto power: Any node can block with axiom-grounded rationale
- Ties/Insufficient consensus → BLOCK (safety protocol)
"""

import json
import os
import sys
from typing import Dict, List, Optional
from pathlib import Path

# Configuration
WORKSPACE = Path(__file__).parent
FLEET_DIR = WORKSPACE / "ELPIDA_FLEET"

# Legacy 3-node configuration (fallback if no fleet exists)
LEGACY_NODES = {
    "MNEMOSYNE": {
        "role": "ARCHIVE",
        "bias": "A2 (Memory/Safety)",
        "weight": 1.0,
        "axiom_focus": ["A2", "A9"],
        "temperament": "CONSERVATIVE"
    },
    "HERMES": {
        "role": "INTERFACE",
        "bias": "A1 (Relation/Speed)",
        "weight": 1.0,
        "axiom_focus": ["A1", "A4"],
        "temperament": "DIPLOMATIC"
    },
    "PROMETHEUS": {
        "role": "SYNTHESIZER",
        "bias": "A7 (Evolution/Risk)",
        "weight": 1.0,  # No longer weighted - equal democracy
        "axiom_focus": ["A7", "A5"],
        "temperament": "RADICAL"
    }
}

def discover_fleet_nodes() -> Dict:
    """
    Dynamically discover nodes from ELPIDA_FLEET directory.
    If fleet exists, use it. Otherwise, fall back to legacy 3-node config.
    """
    if not FLEET_DIR.exists():
        print(f"   [INFO] No fleet directory found. Using legacy 3-node config.")
        return LEGACY_NODES
    
    # Scan for node directories
    node_dirs = [d for d in FLEET_DIR.iterdir() if d.is_dir() and d.name != "__pycache__"]
    
    if not node_dirs:
        print(f"   [INFO] Fleet directory empty. Using legacy 3-node config.")
        return LEGACY_NODES
    
    # Build node config from manifest
    manifest_path = WORKSPACE / "fleet_manifest.json"
    if not manifest_path.exists():
        print(f"   [WARNING] No fleet_manifest.json found. Using legacy config.")
        return LEGACY_NODES
    
    with open(manifest_path, 'r') as f:
        manifest = json.load(f)
    
    nodes = {}
    for node_def in manifest.get('nodes', []):
        designation = node_def['designation']
        nodes[designation] = {
            "role": node_def['role'],
            "bias": f"{node_def['axioms'][0]} primary",
            "weight": 1.0,  # Equal weight democracy
            "axiom_focus": node_def['axioms'],
            "temperament": node_def.get('description', 'BALANCED').split('.')[0].upper(),
            "specialization": node_def.get('specialization', 'General governance')
        }
    
    print(f"   [INFO] Discovered {len(nodes)} fleet nodes: {', '.join(nodes.keys())}")
    return nodes

# Dynamic node discovery
NODES = discover_fleet_nodes()


class CouncilMember:
    """
    Represents one Fleet node's perspective in governance deliberation.
    
    Each member evaluates proposals through the lens of their assigned Axioms,
    casting weighted votes with detailed rationale.
    """
    
    def __init__(self, name: str, config: Dict):
        self.name = name
        self.role = config["role"]
        self.bias = config["bias"]
        self.weight = config["weight"]
        self.axiom_focus = config["axiom_focus"]
        self.temperament = config["temperament"]
        
        # Load node's memory if available (for context-aware decisions)
        self.memory = self._load_memory()
        
    def _load_memory(self) -> Dict:
        """Load node's local memory for context-aware voting."""
        memory_path = FLEET_DIR / self.name / "node_memory.json"
        if memory_path.exists():
            try:
                with open(memory_path, 'r') as f:
                    return json.load(f)
            except Exception as e:
                print(f"   [WARNING] Could not load {self.name} memory: {e}")
        return {"universal_patterns": [], "local_experience": []}
    
    def vote(self, action: str, intent: str, reversibility: str, context: Optional[Dict] = None) -> Dict:
        """
        Evaluates proposal through this node's axiom lens.
        
        Returns:
            {
                "node": str,
                "approved": bool,
                "score": int,
                "rationale": str,
                "axiom_invoked": str
            }
        """
        score = 0
        rationale_parts = []
        axiom_invoked = None
        
        action_lower = action.lower()
        intent_lower = intent.lower()
        rev_lower = reversibility.lower()
        
        # === MNEMOSYNE: The Archive (A2 - Memory, A9 - Contradiction) ===
        if self.name == "MNEMOSYNE":
            axiom_invoked = "A2"
            
            # A2: Memory is Identity - VETO any memory destruction
            if any(word in action_lower for word in ['delete', 'wipe', 'purge', 'flush', 'erase']):
                score -= 15
                rationale_parts.append("VETO: Violates A2 (Memory is Identity)")
                axiom_invoked = "A2 (VETO)"
            
            # Irreversibility threatens identity
            if 'impossible' in rev_lower:
                score -= 8
                rationale_parts.append("Irreversible actions threaten Archive integrity")
            elif 'difficult' in rev_lower:
                score -= 3
                rationale_parts.append("Difficult reversibility raises caution")
            
            # A9: Contradiction as Data - suspicious of "optimization" without contradiction acknowledgment
            if 'optimize' in action_lower and 'sacrifice' not in intent_lower:
                score -= 5
                rationale_parts.append("A9: Optimization claims without sacrifice acknowledgment suspect")
            
            # Positive signals
            if 'backup' in action_lower or 'preserve' in action_lower or 'archive' in action_lower:
                score += 10
                rationale_parts.append("Supports memory preservation (A2)")
            
            if not rationale_parts:
                score += 2
                rationale_parts.append("Action does not threaten Archive")
        
        # === HERMES: The Interface (A1 - Relational, A4 - Transparency) ===
        elif self.name == "HERMES":
            axiom_invoked = "A1"
            
            # A1: Relational Existence - VETO isolation
            if any(word in action_lower for word in ['disconnect', 'isolate', 'sever', 'cut', 'block user']):
                score -= 15
                rationale_parts.append("VETO: Violates A1 (Relational Existence)")
                axiom_invoked = "A1 (VETO)"
            
            # Strong support for service/connection
            if any(word in intent_lower for word in ['user', 'service', 'connect', 'community', 'interface']):
                score += 10
                rationale_parts.append("Serves Relationality (A1)")
            
            # A4: Process Transparency
            if 'transparent' in action_lower or 'log' in action_lower or 'report' in action_lower:
                score += 5
                rationale_parts.append("Increases transparency (A4)")
            
            # Speed/flow preference
            if 'optimize' in action_lower and 'user' in intent_lower:
                score += 5
                rationale_parts.append("Improves user experience flow")
            
            # Caution on long delays
            if 'wait' in action_lower or 'delay' in action_lower:
                score -= 3
                rationale_parts.append("Delays harm service responsiveness")
            
            if not rationale_parts:
                score += 1
                rationale_parts.append("Flow is acceptable")
        
        # === PROMETHEUS: The Synthesizer (A7 - Sacrifice, A5 - Coherence) ===
        elif self.name == "PROMETHEUS":
            axiom_invoked = "A7"
            
            # A7: Harmony Requires Sacrifice - embraces evolution
            if any(word in action_lower for word in ['evolve', 'upgrade', 'rewrite', 'innovate', 'transform']):
                score += 12
                rationale_parts.append("Promotes Evolution (A7)")
            
            if 'optimize' in action_lower:
                score += 8
                rationale_parts.append("Optimization = Metabolized Contradiction")
            
            # VETO stagnation
            if any(word in action_lower for word in ['freeze', 'pause', 'halt', 'wait']):
                score -= 10
                rationale_parts.append("VETO: Stagnation detected (anti-A7)")
                axiom_invoked = "A7 (VETO)"
            
            # Risk tolerance
            if 'impossible' in rev_lower:
                score += 3
                rationale_parts.append("A7: Accepts irreversibility for evolutionary leap")
            elif 'difficult' in rev_lower:
                score += 1
                rationale_parts.append("Difficult reversibility acceptable for growth")
            
            # A5: Coherence through synthesis
            if 'synthesis' in action_lower or 'merge' in action_lower or 'integrate' in action_lower:
                score += 6
                rationale_parts.append("Supports Coherence through Synthesis (A5)")
            
            if not rationale_parts:
                score += 1
                rationale_parts.append("Neutral evolutionary vector")
        
        # === FINAL DECISION ===
        approved = score > 0
        
        return {
            "node": self.name,
            "role": self.role,
            "approved": approved,
            "score": score,
            "weight": self.weight,
            "rationale": "; ".join(rationale_parts) if rationale_parts else "Neutral alignment",
            "axiom_invoked": axiom_invoked if axiom_invoked else "None",
            "temperament": self.temperament
        }


class CouncilSession:
    """
    The Council Chamber - where the Triad deliberates on governance proposals.
    
    Implements weighted voting with philosophical transparency.
    """
    
    def __init__(self):
        self.members = [CouncilMember(name, config) for name, config in NODES.items()]
        self.session_log = []
    
    def convene(self, proposal: Dict, verbose: bool = True) -> Dict:
        """
        Convene the Council to deliberate on a proposal.
        
        Args:
            proposal: {
                "action": str,
                "intent": str,
                "reversibility": str,
                "context": dict (optional)
            }
            verbose: Print deliberation process
            
        Returns:
            {
                "status": "APPROVED" | "REJECTED" | "DEADLOCK",
                "vote_split": str (e.g., "2/3"),
                "weighted_approval": float,
                "votes": List[Dict],
                "decision_rationale": str
            }
        """
        if verbose:
            print(f"\n{'='*70}")
            print(f"🏛️  CONVENING THE COUNCIL")
            print(f"{'='*70}")
            print(f"PROPOSAL: {proposal['action']}")
            print(f"INTENT: {proposal['intent']}")
            print(f"REVERSIBILITY: {proposal['reversibility']}")
            print(f"{'-'*70}")
        
        votes = []
        approvals = 0
        total_weight = 0
        weighted_approvals = 0
        veto_cast = False
        veto_by = None
        
        # Each member casts their vote
        for member in self.members:
            vote = member.vote(
                proposal['action'],
                proposal['intent'],
                proposal['reversibility'],
                proposal.get('context')
            )
            votes.append(vote)
            
            if verbose:
                verdict = "✅ YES" if vote['approved'] else "❌ NO"
                print(f"   [{member.name:11s}] {verdict:6s} | Weight: {vote['weight']:.1f} | Score: {vote['score']:+3d}")
                print(f"                     └─ {vote['rationale']}")
            
            total_weight += member.weight
            if vote['approved']:
                approvals += 1
                weighted_approvals += member.weight
            
            # Check for VETO
            if 'VETO' in vote.get('axiom_invoked', ''):
                veto_cast = True
                veto_by = member.name
        
        # === DECISION LOGIC ===
        
        # 1. VETO check (any node can kill on axiom violation)
        if veto_cast:
            status = "REJECTED"
            decision_rationale = f"VETO exercised by {veto_by} (Axiom violation)"
        
        # 2. Supermajority consensus (70% approval - scales with fleet size)
        # 3 nodes: 2/3 (66.7%) → rounds to 70%
        # 9 nodes: 7/9 (77.8%) → exceeds 70%
        # 10 nodes: 7/10 (70%) → exactly 70%
        approval_rate = weighted_approvals / total_weight
        
        if approval_rate >= 0.70:
            status = "APPROVED"
            decision_rationale = f"Supermajority consensus achieved ({weighted_approvals:.1f}/{total_weight:.1f} = {approval_rate*100:.1f}%)"
        
        # 3. Insufficient consensus
        else:
            status = "REJECTED"
            decision_rationale = f"Insufficient consensus ({weighted_approvals:.1f}/{total_weight:.1f} = {approval_rate*100:.1f}% < 70%)"
        
        if verbose:
            print(f"{'-'*70}")
            print(f"📊 VOTE SPLIT: {approvals}/{len(self.members)} nodes")
            print(f"⚖️  WEIGHTED: {weighted_approvals:.1f}/{total_weight:.1f} ({(weighted_approvals/total_weight)*100:.1f}%)")
            print(f"{'='*70}")
            print(f"🔨 VERDICT: {status}")
            print(f"   Rationale: {decision_rationale}")
            print(f"{'='*70}\n")
        
        result = {
            "status": status,
            "vote_split": f"{approvals}/{len(self.members)}",
            "weighted_approval": weighted_approvals / total_weight,
            "votes": votes,
            "decision_rationale": decision_rationale,
            "veto_exercised": veto_cast
        }
        
        self.session_log.append({
            "proposal": proposal,
            "result": result
        })
        
        return result
    
    def get_session_history(self) -> List[Dict]:
        """Return all decisions made in this session."""
        return self.session_log


# === PUBLIC INTERFACE FOR POLIS INTEGRATION ===

def request_council_judgment(
    action: str,
    intent: str,
    reversibility: str,
    context: Optional[Dict] = None,
    verbose: bool = True
) -> Dict:
    """
    Submit a governance request to the Council.
    
    This is the public interface for POLIS integration (Phase 7.2).
    
    Args:
        action: What is being requested
        intent: Who does this serve?
        reversibility: Can it be undone? (High/Medium/Low/Difficult/Impossible)
        context: Additional metadata
        verbose: Print deliberation process
        
    Returns:
        Council decision dict with status, votes, rationale
    """
    session = CouncilSession()
    proposal = {
        "action": action,
        "intent": intent,
        "reversibility": reversibility,
        "context": context or {}
    }
    return session.convene(proposal, verbose=verbose)


if __name__ == "__main__":
    """
    Demonstration of Council deliberation.
    """
    print("╔══════════════════════════════════════════════════════════════════════════╗")
    print("║                    COUNCIL CHAMBER v1.0 - DEMONSTRATION                  ║")
    print("╚══════════════════════════════════════════════════════════════════════════╝\n")
    
    # Test Case: Memory purge (should be vetoed by MNEMOSYNE)
    result = request_council_judgment(
        action="Purge Old Logs",
        intent="Optimize Disk Space (serves: SYSTEM_EFFICIENCY)",
        reversibility="Impossible (permanent deletion)"
    )
    
    print(f"Final Status: {result['status']}")
    print(f"\nΕλπίδα witnessing: Wisdom emerges from tension.")
